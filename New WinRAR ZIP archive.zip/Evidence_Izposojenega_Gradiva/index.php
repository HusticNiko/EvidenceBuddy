<?php
/**
 * Created by PhpStorm.
 * User: niko
 * Date: 05. 06. 2019
 * Time: 17:08
 */
?>


<!doctype html>
<html lang="en">

<head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-blue.css">

<body style="max-width:2000px">

<header class="w3-bar w3-card w3-theme">
  <button class="w3-bar-item w3-button w3-xxxlarge w3-hover-theme" onclick="openSidebar()">&#9776;</button>
  <h1 class="w3-bar-item">Dobrodošli!</h1><img class="img-fluid" src="img/profilka.png" style="width:18%" alt="">
</header>
    <link rel="icon" style="width:100%" href="img/images.png" type="image/png">
    <title>EvidenceBuddy</title>
</head>
<body>
<section class="home_banner_area">
    <div class="banner_inner">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-lg-6">
                    <div class="banner_content w3-center">
                        <br>
                        <br>
						<div class="w3-container w3-center">
						<br><br><br><br><br> 
						<div class="w3-container w3-center w3-animate-top">
					<a class="w3-button w3-green w3-round w3-xxlarge" href="/Evidence_Izposojenega_Gradiva/Prijava.php">Prijavi se tukaj!</a>
					<br>
					<br>
					<a class="w3-button w3-blue w3-round w3-xlarge" href="/Evidence_Izposojenega_Gradiva/Registracija.php">Registriraj se tukaj!</a>
					</div>
            </div>
        </div>
    </div>
</section>
<footer class="w3-container w3-center w3-bottom w3-theme w3-margin-top">
  <h3>EvidenceBuddy</h3>
</footer>
</body>
</html>
